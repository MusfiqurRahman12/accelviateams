<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$accelvia_monitors = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}accelvia_monitors"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

// Calculate global values for the sexy top boxes
$accelvia_total_sites = count($accelvia_monitors);
$accelvia_up_count = 0;
$accelvia_down_count = 0;
$accelvia_avg_response = 0;
$accelvia_global_uptime = 0;

if ($accelvia_total_sites > 0) {
    foreach ($accelvia_monitors as $accelvia_m) {
        if ($accelvia_m->status === 'up') $accelvia_up_count++;
        if ($accelvia_m->status === 'down') $accelvia_down_count++;
        $accelvia_avg_response += $accelvia_m->avg_response_time;
        $accelvia_global_uptime += $accelvia_m->uptime_percent;
    }
    $accelvia_avg_response = round($accelvia_avg_response / $accelvia_total_sites, 0);
    $accelvia_global_uptime = round($accelvia_global_uptime / $accelvia_total_sites, 2);
}

// Fetch logs for the first monitor to fake the chart history
$accelvia_chart_data_json = '[]';
if ($accelvia_total_sites > 0) {
    $accelvia_first_monitor_id = $accelvia_monitors[0]->id;
    $accelvia_logs = $wpdb->get_results($wpdb->prepare("SELECT response_time, DATE_FORMAT(checked_at, '%%H:%%i') as checked_at FROM {$wpdb->prefix}accelvia_logs WHERE monitor_id = %d ORDER BY id DESC LIMIT 15", $accelvia_first_monitor_id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $accelvia_chart_data_json = wp_json_encode($accelvia_logs);
}
?>


<div class="wrap accelvia-wrap">
    
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h1>Accelvia Global Dashboard</h1>
        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=accelvia-dashboard&action=manual_sync'), 'accelvia_manual_sync')); ?>" id="ac-sync-btn" class="ac-btn outline">Sync Now 🔄</a>
    </div>

    <?php if (isset($_GET['synced']) && wp_verify_nonce(isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '', 'accelvia_manual_sync')): // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
        <div style="background: rgba(16, 185, 129, 0.1); color: var(--ac-success); border: 1px solid var(--ac-success); padding: 10px; border-radius: 8px; margin-bottom: 20px;">
            ✅ <strong>Global Sync Complete:</strong> Dispatched manual Ping to the Edge nodes successfully.
        </div>
    <?php endif; ?>

    <div class="ac-stats-grid">
        <div class="ac-stat-box">
            <div class="ac-stat-label">Global Uptime</div>
            <div class="ac-stat-value" style="color: var(--ac-success);"><?php echo esc_html($accelvia_global_uptime > 0 ? $accelvia_global_uptime : '100.00'); ?>%</div>
        </div>
        <div class="ac-stat-box">
            <div class="ac-stat-label">System Status</div>
            <div class="ac-stat-value">
                <?php if($accelvia_down_count > 0): ?>
                    <span style="color: var(--ac-danger); font-size: 24px;">🚨 <?php echo esc_html($accelvia_down_count); ?> DOWN</span>
                <?php else: ?>
                    <span style="color: var(--ac-success); font-size: 24px;">✅ ALL CLEAR</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="ac-stat-box">
            <div class="ac-stat-label">Avg Global Route Time</div>
            <div class="ac-stat-value"><?php echo esc_html($accelvia_avg_response); ?> ms</div>
        </div>
        <div class="ac-stat-box">
            <div class="ac-stat-label">Active Nodes</div>
            <div class="ac-stat-value"><?php echo esc_html($accelvia_total_sites); ?></div>
        </div>
        <div class="ac-stat-box">
            <div class="ac-stat-label">WP-Cron Engine</div>
            <div class="ac-stat-value" style="font-size: 20px;">
                <?php
                $accelvia_next_cron = wp_next_scheduled('accelvia_hourly_check');
                if (!$accelvia_next_cron || $accelvia_next_cron < (time() - 3600)) {
                    echo '<span style="color: var(--ac-danger);">🚨 FAILED</span>';
                } else {
                    echo '<span style="color: var(--ac-success);">✅ ACTIVE</span>';
                }
                ?>
            </div>
            <div style="font-size: 11px; color: var(--ac-text-muted); margin-top: 5px;">Local Check Health</div>
        </div>
    </div>

    <div class="ac-card">
        <h2>Performance Matrix (<?php echo $accelvia_total_sites > 0 ? esc_html($accelvia_monitors[0]->friendly_name) : 'No Sites Added'; ?>)</h2>
        <?php if ($accelvia_total_sites > 0 && !empty($accelvia_logs)) : ?>
            <div style="position: relative; height: 300px; width: 100%;">
                <canvas id="responseChart" data-chartdata="<?php echo esc_attr($accelvia_chart_data_json); ?>"></canvas>
            </div>
        <?php else: ?>
            <div style="color: var(--ac-text-muted); padding: 50px 0; text-align: center;">Waiting for performance data from the global nodes... This can take up to an hour.</div>
        <?php endif; ?>
    </div>

    <div class="ac-card">
        <h2>Monitored Endpoints</h2>
        <table class="ac-table">
            <thead>
                <tr>
                    <th>Target</th>
                    <th>Status</th>
                    <th>Uptime</th>
                    <th>Ping</th>
                    <th>Lighthouse</th>
                    <th>Last Sync</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($accelvia_total_sites == 0): ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: var(--ac-text-muted); padding: 20px;">
                        No endpoints monitored yet. The plugin will auto-register your site on activation.
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach($accelvia_monitors as $accelvia_m): ?>
                    <tr>
                        <td style="font-weight: 500;">
                            <?php echo esc_html($accelvia_m->friendly_name); ?><br>
                            <span style="font-size: 11px; color: var(--ac-text-muted);"><?php echo esc_url($accelvia_m->url); ?></span>
                            <?php if (!empty($accelvia_m->ssl_valid_to)): 
                                $accelvia_ssl_days = floor((strtotime($accelvia_m->ssl_valid_to) - time()) / 86400);
                                $accelvia_ssl_color = $accelvia_ssl_days <= 1 ? 'var(--ac-danger)' : ($accelvia_ssl_days <= 7 ? 'var(--ac-warning)' : 'var(--ac-text-muted)');
                            ?>
                                <br><span style="font-size: 11px; color: <?php echo esc_attr($accelvia_ssl_color); ?>;">🔐 SSL Expires in <?php echo esc_html($accelvia_ssl_days); ?> day(s)</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="ac-badge <?php echo esc_attr($accelvia_m->status); ?>">
                                <div class="ac-pulse-dot"></div>
                                <?php echo esc_html($accelvia_m->status); ?>
                            </div>
                        </td>
                        <td style="font-family: monospace; font-size: 14px;"><?php echo esc_html($accelvia_m->uptime_percent); ?>%</td>
                        <td style="font-family: monospace; font-size: 14px;"><?php echo esc_html($accelvia_m->avg_response_time); ?> ms</td>
                        <td>
                            <div style="font-size: 13px; display: flex; flex-direction: column; gap: 4px;">
                                <span title="Desktop Score">🖥️ 
                            <?php 
                            if (isset($accelvia_m->pagespeed_desktop) && $accelvia_m->pagespeed_desktop == -1) {
                                echo '<span style="color:var(--ac-warning);">Rate Limited</span>';
                            } elseif (isset($accelvia_m->pagespeed_desktop) && $accelvia_m->pagespeed_desktop > 0) {
                                echo esc_html($accelvia_m->pagespeed_desktop);
                            } else {
                                echo '--';
                            }
                            ?></span>
                            <span title="Mobile Score">📱 
                            <?php 
                            if (isset($accelvia_m->pagespeed_mobile) && $accelvia_m->pagespeed_mobile == -1) {
                                echo '<span style="color:var(--ac-warning);">Rate Limited</span>';
                            } elseif (isset($accelvia_m->pagespeed_mobile) && $accelvia_m->pagespeed_mobile > 0) {
                                echo esc_html($accelvia_m->pagespeed_mobile);
                            } else {
                                echo '--';
                            }
                            ?></span>
                            </div>
                        </td>
                        <td style="color: var(--ac-text-muted); font-size: 12px;">
                            <?php echo $accelvia_m->last_checked === '0000-00-00 00:00:00' ? 'Pending' : esc_html(human_time_diff(strtotime(get_gmt_from_date($accelvia_m->last_checked)), time())) . ' ago'; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php
    $accelvia_all_logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}accelvia_logs ORDER BY id DESC LIMIT 25"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    ?>
    <div class="ac-card" style="margin-top: 30px;">
        <h2>Raw Edge Activity Logs</h2>
        <p style="color: var(--ac-text-muted); margin-bottom: 15px;">The exact HTTP status codes and millisecond ping vectors returned from the global Edge cloud network during the last 25 checks.</p>
        <table class="ac-table">
            <thead>
                <tr>
                    <th>Timestamp (Server Default)</th>
                    <th>Node State Target</th>
                    <th>Latency Vector</th>
                    <th>Node Assessment</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($accelvia_all_logs)): ?>
                    <tr><td colspan="4" style="text-align:center; padding: 20px;">No manual or scheduled activity logged globally yet. Hit Sync Now.</td></tr>
                <?php else: ?>
                    <?php foreach($accelvia_all_logs as $accelvia_log): ?>
                    <tr>
                        <td style="color:var(--ac-text-muted); font-size:12px;">⌚ <?php echo esc_html(gmdate('M d, H:i:s', strtotime($accelvia_log->checked_at))); ?></td>
                        <td>
                            <span style="font-family:monospace; padding: 4px 8px; border-radius: 4px; background: rgba(255,255,255,0.05); color: <?php echo $accelvia_log->status === 'up' ? 'var(--ac-success)' : 'var(--ac-danger)'; ?>">
                                <?php echo esc_html(strtoupper($accelvia_log->status)); ?>
                                <?php if (isset($accelvia_log->status_code) && $accelvia_log->status_code !== '0' && $accelvia_log->status_code !== '') echo ' (' . esc_html($accelvia_log->status_code) . ')'; ?>
                            </span>
                        </td>
                        <td style="font-family:monospace;"><?php echo esc_html($accelvia_log->response_time); ?> ms</td>
                        <td>
                            <?php if($accelvia_log->status === 'up'): ?>
                                <span class="ac-badge up" style="padding: 2px 8px; font-size: 11px;">Optimal</span>
                            <?php else: ?>
                                <span class="ac-badge down" style="padding: 2px 8px; font-size: 11px;">Crash Detected</span>
                                <?php if(!empty($accelvia_log->error_detail)): ?>
                                    <div style="font-size: 11px; font-family: monospace; color: var(--ac-danger); margin-top: 6px; background: rgba(239, 68, 68, 0.1); padding: 5px; border-radius: 4px; max-width: 280px; word-wrap: break-word;">
                                        🔥 <?php echo esc_html($accelvia_log->error_detail); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
