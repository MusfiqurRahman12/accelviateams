<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap accelvia-wrap">
    <h1>Notification Routing Engine</h1>

    <?php if (isset($_GET['updated']) && isset($_GET['_wpnonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'accelvia_save_settings')): // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
        <div style="background: rgba(16, 185, 129, 0.1); color: var(--ac-success); border: 1px solid var(--ac-success); padding: 10px; border-radius: 8px; margin-bottom: 20px;">
            ✅ Accelvia Notification Settings Synced globally.
        </div>
    <?php endif; ?>

    <div class="ac-card" style="max-width: 800px;">
        <p style="color: var(--ac-text-muted); margin-bottom: 24px;">Configure where your node alerts will be broadcasted. You can enable one, or multiple parallel paths simultaneously for instantaneous uptime drops and security breach detections.</p>

        <form method="POST" action="admin.php?page=accelvia-settings">
            <?php wp_nonce_field('accelvia_save_settings'); ?>
            <input type="hidden" name="accelvia_action" value="save_settings">

            <!-- GLOBAL EDGE FALLBACK ENGINE -->
            <h2>Autonomous Edge Fallback</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 15px; font-size: 13px;">If your entire server completely crashes (e.g., cPanel deleted, network failure, local cron death), this WP Plugin physically cannot alert you because PHP will not run. Turning this on will securely push your Discord, Slack, and Channel keys directly into the global Edge Proxy network. The Edge network will autonomously ping your server every 1-hour and independently shoot the disaster alerts to your channels if the WP engine ever drops entirely!</p>
            <div class="ac-form-group" style="display: flex; align-items: center; gap: 10px; margin-bottom: 30px;">
                <input type="checkbox" id="edge_fallback_enabled" name="edge_fallback_enabled" value="yes" <?php checked(get_option('accelvia_edge_fallback_enabled'), 'yes'); ?>>
                <label for="edge_fallback_enabled" style="margin: 0; padding: 0; color:var(--ac-success); font-weight: bold;">Enable Deadman's Switch (Global Edge Dispatcher)</label>
            </div>

            <!-- DEFACEMENT PROTECTION -->
            <h2>Defacement Protection (Local Check)</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 15px; font-size: 13px;">Specify a keyword (e.g. your company name or footer text). If this keyword is missing from the page during a local ping, it will trigger an instant "down" alert warning of possible defacement or a white-screen crash.</p>
            <div class="ac-form-group">
                <label for="defacement_keyword">Required Page Keyword</label>
                <input type="text" id="defacement_keyword" name="defacement_keyword" value="<?php echo esc_attr(get_option('accelvia_defacement_keyword')); ?>" placeholder="e.g. Accelvia">
            </div>

            <!-- LIGHTHOUSE SEO -->
            <h2>Google Lighthouse API Key (Optional)</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 15px; font-size: 13px;">Google heavily rate-limits free/unauthenticated requests which results in `--` or `-1` scores. Obtain a free PageSpeed Insights API Key from Google Cloud Platform to bypass these limits.</p>
            <div class="ac-form-group">
                <label for="pagespeed_api_key">PageSpeed API Key</label>
                <input type="text" id="pagespeed_api_key" name="pagespeed_api_key" value="<?php echo esc_attr(get_option('accelvia_pagespeed_api_key')); ?>" placeholder="AIzaSy...">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- EMAIL -->
            <h2>Native Email (No APIs Required)</h2>
            <div class="ac-form-group">
                <label for="alert_email">Primary Admin Email</label>
                <input type="email" id="alert_email" name="alert_email" value="<?php echo esc_attr(get_option('accelvia_alert_email')); ?>" placeholder="admin@mycompany.com">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- WHATSAPP -->
            <h2>WhatsApp Engine (via CallMeBot)</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 15px; font-size: 13px;">
                <strong>💡 Quick Setup Guide:</strong> To use personal WhatsApp notifications free of Meta's strict business templating restrictions, we utilize native CallMeBot architecture.<br/>
                1. Add the phone number <strong>+34 624 54 19 86</strong> to your contacts.<br/>
                2. Send them a WhatsApp text: <code>I allow callmebot to send me messages</code><br/>
                3. The bot will instantly reply with an API Key to paste below.
            </p>
            <div class="ac-form-group">
                <label for="whatsapp_number">Your WhatsApp Phone Number (Include international code e.g., +1234567890)</label>
                <input type="text" id="whatsapp_number" name="whatsapp_number" value="<?php echo esc_attr(get_option('accelvia_whatsapp_number')); ?>" placeholder="+1234567890">
            </div>
            <div class="ac-form-group">
                <label for="whatsapp_apikey">CallMeBot Key</label>
                <input type="password" id="whatsapp_apikey" name="whatsapp_apikey" value="<?php echo esc_attr(get_option('accelvia_whatsapp_apikey')); ?>" placeholder="Paste the secret bot key here">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- TELEGRAM -->
            <h2>Telegram Engine</h2>
            <div class="ac-form-group">
                <label for="telegram_token">Telegram Bot Token (e.g., 12345:ABCDE)</label>
                <input type="password" id="telegram_token" name="telegram_token" value="<?php echo esc_attr(get_option('accelvia_telegram_token')); ?>" placeholder="Generate via @BotFather on Telegram">
            </div>

            <div class="ac-form-group">
                <label for="telegram_chat_id">Telegram Chat ID (e.g., -100XXXX OR your personal ID)</label>
                <input type="text" id="telegram_chat_id" name="telegram_chat_id" value="<?php echo esc_attr(get_option('accelvia_telegram_chat_id')); ?>" placeholder="Chat destination ID">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- DISCORD -->
            <h2>Discord Webhook Integration</h2>
            <div class="ac-form-group">
                <label for="discord_webhook">Discord Server Webhook URL</label>
                <input type="url" id="discord_webhook" name="discord_webhook" value="<?php echo esc_attr(get_option('accelvia_discord_webhook')); ?>" placeholder="https://discord.com/api/webhooks/.../...">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- SLACK -->
            <h2>Slack Webhook Integration</h2>
            <div class="ac-form-group">
                <label for="slack_webhook">Slack Incoming Webhook URL</label>
                <input type="url" id="slack_webhook" name="slack_webhook" value="<?php echo esc_attr(get_option('accelvia_slack_webhook')); ?>" placeholder="https://hooks.slack.com/services/.../...">
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- DATA RETENTION -->
            <h2>Data Retention Strategy</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 24px;">To prevent database bloat, Accelvia automatically prunes historical ping vectors older than your selected timeframe.</p>
            <div class="ac-form-group">
                <label for="log_retention_days">Auto-Prune Logs Older Than</label>
                <select id="log_retention_days" name="log_retention_days" style="width: 100%; padding: 12px; background: rgba(0,0,0,0.2); border: 1px solid var(--ac-border); color: white; border-radius: 6px;">
                    <option value="30" <?php selected(get_option('accelvia_log_retention_days', 90), 30); ?>>30 Days</option>
                    <option value="90" <?php selected(get_option('accelvia_log_retention_days', 90), 90); ?>>90 Days (Recommended)</option>
                    <option value="180" <?php selected(get_option('accelvia_log_retention_days', 90), 180); ?>>180 Days</option>
                    <option value="365" <?php selected(get_option('accelvia_log_retention_days', 90), 365); ?>>1 Year</option>
                </select>
            </div>

            <hr style="border-color: var(--ac-border); margin: 30px 0;">

            <!-- PERIODIC REPORTS -->
            <h2>Periodic Summary Reports</h2>
            <p style="color: var(--ac-text-muted); margin-bottom: 24px;">Automatically aggregate network latency and health over the last timeframe, dispatched precisely to your chosen networks.</p>

            <div class="ac-form-group" style="display: flex; align-items: center; gap: 10px;">
                <input type="checkbox" id="reports_enabled" name="reports_enabled" value="yes" <?php checked(get_option('accelvia_reports_enabled'), 'yes'); ?>>
                <label for="reports_enabled" style="margin: 0; padding: 0;">Enable Automated Periodic Reports</label>
            </div>

            <div class="ac-form-group">
                <label for="reports_frequency">Execution Frequency</label>
                <select id="reports_frequency" name="reports_frequency" style="width: 100%; padding: 12px; background: rgba(0,0,0,0.2); border: 1px solid var(--ac-border); color: white; border-radius: 6px;">
                    <option value="hourly" <?php selected(get_option('accelvia_reports_frequency'), 'hourly'); ?>>Hourly (Every 1 Hour)</option>
                    <option value="daily" <?php selected(get_option('accelvia_reports_frequency'), 'daily'); ?>>Daily (Every 24 Hours)</option>
                    <option value="weekly" <?php selected(get_option('accelvia_reports_frequency'), 'weekly'); ?>>Weekly (Every 7 Days)</option>
                </select>
            </div>

            <div class="ac-form-group">
                <label>Target Delivery Channels</label>
                <p style="color: var(--ac-text-muted); font-size: 13px; margin-bottom: 5px;">Select exclusively which endpoints will receive the periodic Network Summary (Instant Panic alerts will still go to all configured terminals above).</p>
                <?php $accelvia_channels = get_option('accelvia_reports_channels', array()); ?>
                <div style="display: flex; gap: 20px; margin-top: 10px;">
                    <label><input type="checkbox" name="reports_channels[]" value="email" <?php checked(in_array('email', $accelvia_channels)); ?>> Native Email</label>
                    <label><input type="checkbox" name="reports_channels[]" value="discord" <?php checked(in_array('discord', $accelvia_channels)); ?>> Discord Embed</label>
                    <label><input type="checkbox" name="reports_channels[]" value="slack" <?php checked(in_array('slack', $accelvia_channels)); ?>> Slack Blocks</label>
                    <label><input type="checkbox" name="reports_channels[]" value="telegram" <?php checked(in_array('telegram', $accelvia_channels)); ?>> Telegram Msg</label>
                    <label><input type="checkbox" name="reports_channels[]" value="whatsapp" <?php checked(in_array('whatsapp', $accelvia_channels)); ?>> WhatsApp Msg</label>
                </div>
            </div>

            <div style="margin-top: 40px;">
                <button type="submit" class="ac-btn">Commit Notification Node Architecture</button>
            </div>
        </form>
    </div>
</div>
