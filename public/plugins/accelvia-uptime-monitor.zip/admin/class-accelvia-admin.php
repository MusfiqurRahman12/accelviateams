<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Accelvia_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'register_menus'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Handle Form Submissions
        add_action('admin_init', array($this, 'handle_submissions'));
    }

    public function register_menus() {
        add_menu_page(
            'Accelvia Monitor',
            'Accelvia Monitor',
            'manage_options',
            'accelvia-dashboard',
            array($this, 'render_dashboard'),
            'dashicons-chart-area',
            99
        );
        add_submenu_page(
            'accelvia-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'accelvia-dashboard',
            array($this, 'render_dashboard')
        );
        add_submenu_page(
            'accelvia-dashboard',
            'Settings',
            'Settings',
            'manage_options',
            'accelvia-settings',
            array($this, 'render_settings')
        );
    }

    public function enqueue_scripts($hook) {
        if (strpos($hook, 'accelvia') !== false) {
            wp_enqueue_style('accelvia-admin-css', ACCELVIA_MONITOR_URL . 'admin/assets/accelvia-admin.css', array(), ACCELVIA_MONITOR_VERSION);
            wp_enqueue_script('chart-js', ACCELVIA_MONITOR_URL . 'admin/assets/chart.min.js', array(), '4.5.1', true);
            wp_enqueue_script('accelvia-admin-js', ACCELVIA_MONITOR_URL . 'admin/assets/accelvia-admin.js', array('jquery'), ACCELVIA_MONITOR_VERSION, true);
            wp_localize_script('accelvia-admin-js', 'accelvia_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('accelvia_sync_nonce'),
            ));
        }
    }

    public function handle_submissions() {
        if (isset($_GET['action']) && $_GET['action'] == 'manual_sync') {
            if (!current_user_can('manage_options')) {
                wp_die(esc_html__('Unauthorized access.', 'accelvia-uptime-monitor'));
            }
            check_admin_referer('accelvia_manual_sync');
            $engine = new Accelvia_Engine();
            $engine->sync_monitors(true); // $force_local = true override
            $engine->update_pagespeed(); // Force PageSpeed trigger
            wp_safe_redirect(admin_url('admin.php?page=accelvia-dashboard&synced=true'));
            exit;
        }

        if (isset($_POST['accelvia_action']) && $_POST['accelvia_action'] == 'save_settings' && check_admin_referer('accelvia_save_settings')) {
            update_option('accelvia_telegram_token', isset($_POST['telegram_token']) ? sanitize_text_field(wp_unslash($_POST['telegram_token'])) : '');
            update_option('accelvia_telegram_chat_id', isset($_POST['telegram_chat_id']) ? sanitize_text_field(wp_unslash($_POST['telegram_chat_id'])) : '');
            update_option('accelvia_alert_email', isset($_POST['alert_email']) ? sanitize_email(wp_unslash($_POST['alert_email'])) : '');
            update_option('accelvia_whatsapp_number', isset($_POST['whatsapp_number']) ? sanitize_text_field(wp_unslash($_POST['whatsapp_number'])) : '');
            update_option('accelvia_whatsapp_apikey', isset($_POST['whatsapp_apikey']) ? sanitize_text_field(wp_unslash($_POST['whatsapp_apikey'])) : '');
            update_option('accelvia_discord_webhook', isset($_POST['discord_webhook']) ? esc_url_raw(wp_unslash($_POST['discord_webhook'])) : '');
            update_option('accelvia_slack_webhook', isset($_POST['slack_webhook']) ? esc_url_raw(wp_unslash($_POST['slack_webhook'])) : '');
            update_option('accelvia_defacement_keyword', isset($_POST['defacement_keyword']) ? sanitize_text_field(wp_unslash($_POST['defacement_keyword'])) : '');
            update_option('accelvia_pagespeed_api_key', isset($_POST['pagespeed_api_key']) ? sanitize_text_field(wp_unslash($_POST['pagespeed_api_key'])) : '');
            
            // Reporting Logic Saves
            update_option('accelvia_reports_enabled', isset($_POST['reports_enabled']) ? 'yes' : 'no');
            update_option('accelvia_reports_frequency', isset($_POST['reports_frequency']) ? sanitize_text_field(wp_unslash($_POST['reports_frequency'])) : 'daily');
            update_option('accelvia_reports_channels', isset($_POST['reports_channels']) ? array_map('sanitize_text_field', wp_unslash($_POST['reports_channels'])) : array());
            
            // Log Retention Save
            update_option('accelvia_log_retention_days', isset($_POST['log_retention_days']) ? intval($_POST['log_retention_days']) : 90);
            
            // Edge Fallback Deadman Switch
            update_option('accelvia_edge_fallback_enabled', isset($_POST['edge_fallback_enabled']) ? 'yes' : 'no');
            
            // Re-sync all configurations outward to the Edge infrastructure
            $engine = new Accelvia_Engine();
            $engine->sync_edge_config();
            
            wp_safe_redirect(admin_url('admin.php?page=accelvia-settings&updated=true'));
            exit;
        }
    }

    public function render_dashboard() {
        include ACCELVIA_MONITOR_DIR . 'admin/views/dashboard.php';
    }

    public function render_settings() {
        include ACCELVIA_MONITOR_DIR . 'admin/views/settings.php';
    }
}
