/* Accelvia Admin Custom JS */

document.addEventListener('DOMContentLoaded', function() {

    // 2. Initialize Chart.js if canvas exists
    const ctx = document.getElementById('responseChart');
    if (ctx && typeof Chart !== 'undefined') {
        const rawData = JSON.parse(ctx.dataset.chartdata || '[]');
        
        const labels = rawData.map(d => d.checked_at).reverse();
        const data = rawData.map(d => d.response_time).reverse();

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Response Time (ms)',
                    data: data,
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#0f111a',
                    pointBorderColor: '#6366f1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255,255,255,0.05)', borderColor: 'transparent' },
                        ticks: { color: '#9ca3af' }
                    },
                    y: {
                        grid: { color: 'rgba(255,255,255,0.05)', borderColor: 'transparent' },
                        ticks: { color: '#9ca3af' },
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // 3. Sync Action
    const syncBtn = document.getElementById('ac-sync-btn');
    if(syncBtn) {
        syncBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const btn = this;
            const originalText = btn.innerHTML;
            btn.innerHTML = 'Synching...';
            btn.style.pointerEvents = 'none';
            
            fetch(accelvia_ajax.ajax_url + '?action=accelvia_sync_now&nonce=' + accelvia_ajax.nonce)
                .then(response => response.json())
                .then(data => {
                    btn.innerHTML = 'Synced ✅';
                    setTimeout(() => location.reload(), 1000);
                });
        });
    }
});
