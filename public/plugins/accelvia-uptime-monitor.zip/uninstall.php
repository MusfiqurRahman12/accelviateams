<?php
/**
 * Accelvia Uptime Monitor - Uninstall
 *
 * Cleans up all plugin data when the plugin is deleted via the WordPress admin.
 * This file is executed automatically by WordPress core on plugin deletion.
 *
 * @package Accelvia_Uptime_Monitor
 */

// Abort if not called by WordPress
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Drop custom database tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}accelvia_logs" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}accelvia_monitors" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

// Remove all plugin options
$accelvia_options_to_delete = array(
    'accelvia_telegram_token',
    'accelvia_telegram_chat_id',
    'accelvia_alert_email',
    'accelvia_whatsapp_number',
    'accelvia_whatsapp_apikey',
    'accelvia_discord_webhook',
    'accelvia_api_secret',
    'accelvia_reports_enabled',
    'accelvia_reports_frequency',
    'accelvia_reports_channels',
    'accelvia_last_report_time',
    'accelvia_db_version',
);

foreach ( $accelvia_options_to_delete as $accelvia_option ) {
    delete_option( $accelvia_option );
}

// Remove all file integrity hash options (dynamic keys)
$accelvia_hash_options = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'accelvia_hash_%'"
);
foreach ( $accelvia_hash_options as $accelvia_hash_option ) {
    delete_option( $accelvia_hash_option );
}

// Clear any remaining scheduled cron events
wp_clear_scheduled_hook( 'accelvia_hourly_check' );
wp_clear_scheduled_hook( 'accelvia_daily_security_check' );
wp_clear_scheduled_hook( 'accelvia_daily_log_prune' );
