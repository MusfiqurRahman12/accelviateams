<?php
/**
 * Plugin Name:       Accelvia Uptime Monitor
 * Plugin URI:        https://accelviateams.com/accelvia-uptime-monitor
 * Description:       A self-hosted uptime monitoring plugin with dual-layer architecture, SSL tracking, defacement detection, and multi-channel alerting.
 * Version:           1.0.3
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            musfiqurrahman
 * Author URI:        https://accelviateams.com/musfiqurrahman
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       accelvia-uptime-monitor
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'ACCELVIA_MONITOR_VERSION', '1.0.3' );
define( 'ACCELVIA_MONITOR_DIR', plugin_dir_path( __FILE__ ) );
define( 'ACCELVIA_MONITOR_URL', plugin_dir_url( __FILE__ ) );

// Load dependencies
require_once ACCELVIA_MONITOR_DIR . 'includes/class-accelvia-db.php';
require_once ACCELVIA_MONITOR_DIR . 'includes/class-accelvia-engine.php';
require_once ACCELVIA_MONITOR_DIR . 'includes/class-accelvia-alerts.php';
require_once ACCELVIA_MONITOR_DIR . 'includes/class-accelvia-security.php';
require_once ACCELVIA_MONITOR_DIR . 'admin/class-accelvia-admin.php';

// Activation Hook
register_activation_hook( __FILE__, array( 'Accelvia_DB', 'create_tables' ) );
register_activation_hook( __FILE__, array( 'Accelvia_Engine', 'schedule_cron' ) );
register_activation_hook( __FILE__, array( 'Accelvia_Security', 'schedule_cron' ) );

// Deactivation Hook
register_deactivation_hook( __FILE__, array( 'Accelvia_Engine', 'clear_cron' ) );
register_deactivation_hook( __FILE__, array( 'Accelvia_Security', 'clear_cron' ) );

// Initialize the plugin
function accelvia_monitor_init() {
    Accelvia_DB::check_version();
    new Accelvia_Engine();
    new Accelvia_Alerts();
    new Accelvia_Security();
    if ( is_admin() ) {
        new Accelvia_Admin();
    }
}
add_action( 'plugins_loaded', 'accelvia_monitor_init' );

// Add action links on Plugins list page
function accelvia_monitor_action_links( $links ) {
    $settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=accelvia-settings' ) ) . '">' . esc_html__( 'Settings', 'accelvia-uptime-monitor' ) . '</a>';
    $site_link = '<a href="https://accelviateams.com/accelvia-uptime-monitor" target="_blank">' . esc_html__( 'Visit Plugin Site', 'accelvia-uptime-monitor' ) . '</a>';
    array_unshift( $links, $settings_link, $site_link );
    return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'accelvia_monitor_action_links' );
