=== Accelvia Uptime Monitor ===
Contributors: musfiqurrahman
Tags: uptime monitor, downtime alert, ssl checker, website performance, deadman switch
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A self-hosted WordPress uptime monitoring plugin with dual-layer architecture, SSL tracking, defacement detection, and multi-channel alerting.

== Description ==

Accelvia Uptime Monitor turns your WordPress installation into a self-hosted website monitoring system. Instead of relying on external SaaS platforms, this plugin uses your local WordPress database to store uptime logs and performance metrics directly on your server.

The plugin features a **Dual-Layer Architecture**: WordPress handles local analytics (HTML parsing, SSL certificate inspection), and optionally synchronizes with an external Edge Network. If your WordPress server goes offline, the external "Deadman's Switch" detects the failure and sends alerts independently.

### Key Features

* **Dual-Layer Monitoring:** The plugin monitors your site locally via WordPress cron. Optionally, an external Edge Fallback (Deadman's Switch) can detect total server failures and send alerts even when your WordPress installation is unreachable.
* **Self-Hosted Data Storage:** All historical analytics, ping logs, and configuration data are stored in your own WordPress database. No external accounts or subscriptions are required for core monitoring.
* **SSL Certificate Tracking:** During each monitoring cycle, the plugin inspects the SSL/TLS certificate of your site and calculates the remaining days until expiration. It sends warning alerts at 7 days, 3 days, and 1 day before expiry.
* **Defacement and Crash Detection:** You can configure a "Master Keyword" that must be present in your site's HTML output. If the keyword is missing (indicating a white screen, database error, or content tampering), the plugin marks the site as down.
* **Multi-Channel Alerting:** Route alerts and periodic summary reports to Email, Slack, Discord, Telegram, and WhatsApp simultaneously. All channels are configured from the plugin settings page.

### Additional Capabilities

* **Edge Fallback (Deadman's Switch):** An optional external cloud service that continuously polls your site. If WordPress becomes completely unreachable, the external service sends alerts on your behalf.
* **SSL Expiry Countdown:** Automatically dispatches alerts at 7-day, 3-day, and 1-day intervals before your SSL certificate expires.
* **Keyword-Based Content Verification:** Verifies that specific content exists in your page's HTML source, catching silent failures that return HTTP 200 but serve broken content.
* **Local Analytics Logging:** Stores all monitoring data in your WordPress MySQL database with configurable retention periods.
* **PageSpeed Insights Integration:** Queries Google's PageSpeed Insights API daily to track Desktop and Mobile performance scores over time.

== Installation ==

1. Upload the `accelvia-uptime-monitor` plugin directory to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Access "Accelvia Monitor" in the sidebar to configure your notification settings and edge networking.
4. Your site is automatically monitored upon activation — no manual setup required.

== Configuration: Server-Side Cron ==

By default, WordPress relies on "simulated cron" (WP-Cron), which only fires when a user visits your website. If your site receives low traffic, your uptime checks may be delayed.

For accurate monitoring intervals, consider disabling default WP-Cron and setting up a server-side cron job (via cPanel or your hosting dashboard) to execute `wp-cron.php` every 5 minutes.

This ensures the monitoring engine executes on schedule regardless of website traffic.

== External Services ==

This plugin connects to the following third-party and external services. Each service is used only when the corresponding feature is enabled and configured by the site administrator.

= Accelvia API Proxy (Edge Fallback / Deadman's Switch) =

When the "Edge Fallback" feature is enabled in Settings, the plugin sends your monitored URLs, site identifier hash, and configured alert channel credentials to an external proxy service hosted on Vercel. This proxy independently pings your site and sends alerts if your WordPress server becomes completely unreachable.

* **Service URL:** https://accelvia-api-proxy.vercel.app
* **Data sent:** Monitored URLs, a hashed site identifier, and alert channel configuration (webhook URLs, API tokens).
* **When sent:** Each time settings are saved with Edge Fallback enabled, and during scheduled sync cycles.
* **Service provider:** Accelvia (hosted on Vercel)
* **Vercel Terms of Service:** https://vercel.com/legal/terms
* **Vercel Privacy Policy:** https://vercel.com/legal/privacy-policy

= Telegram Bot API =

When a Telegram Bot Token and Chat ID are configured in Settings, the plugin sends alert messages and periodic reports to the Telegram Bot API.

* **Service URL:** https://api.telegram.org
* **Data sent:** Alert text content (site name, status, error details) and the configured Chat ID.
* **When sent:** On status changes (up/down), SSL expiry warnings, and scheduled periodic reports (if Telegram channel is selected).
* **Service provider:** Telegram FZ-LLC
* **Telegram Terms of Service:** https://telegram.org/tos
* **Telegram Privacy Policy:** https://telegram.org/privacy

= CallMeBot WhatsApp API =

When a WhatsApp phone number and CallMeBot API key are configured in Settings, the plugin sends alert messages via the CallMeBot free API service.

* **Service URL:** https://api.callmebot.com
* **Data sent:** Alert text content, the configured phone number, and CallMeBot API key.
* **When sent:** On status changes (up/down), SSL expiry warnings, and scheduled periodic reports (if WhatsApp channel is selected).
* **Service provider:** CallMeBot
* **CallMeBot Website / Info:** https://www.callmebot.com
* **CallMeBot Privacy Info:** https://www.callmebot.com/privacy-policy/

= Google PageSpeed Insights API =

The plugin queries Google's PageSpeed Insights API once daily to retrieve Desktop and Mobile performance scores for each monitored URL.

* **Service URL:** https://www.googleapis.com/pagespeedonline/v5/runPagespeed
* **Data sent:** The monitored URL and optionally a user-provided API key.
* **When sent:** Once daily via WordPress scheduled cron, and on manual sync.
* **Service provider:** Google LLC
* **Google Terms of Service:** https://policies.google.com/terms
* **Google Privacy Policy:** https://policies.google.com/privacy

= Domain Registration Expiry Check (RDAP Protocol) =

The plugin's daily security scan checks the domain registration expiration date of each monitored site using RDAP (Registration Data Access Protocol), the official successor to WHOIS as designated by ICANN. RDAP queries are sent directly to the authoritative domain registry for each supported TLD.

* **Data sent:** The domain name of each monitored URL.
* **When sent:** Once daily during the scheduled security scan.
* **Supported TLDs and their authoritative RDAP servers:**
  * .com / .net domains are queried via Verisign (https://rdap.verisign.com)
  * .org domains are queried via Public Interest Registry / PIR (https://rdap.publicinterestregistry.org)
* **Protocol specification:** RDAP is an IETF/ICANN standard (RFC 9082, RFC 9083).
* **ICANN RDAP Information:** https://www.icann.org/rdap
* **Verisign Terms of Service:** https://www.verisign.com/en_US/terms-of-service/index.xhtml
* **Verisign Privacy Policy:** https://www.verisign.com/en_US/privacy/index.xhtml
* **PIR (Public Interest Registry) Policies:** https://thenew.org/org-people/about-pir/policies/

= Discord and Slack Webhooks =

When Discord or Slack webhook URLs are configured in Settings, the plugin posts alert messages and periodic reports to those webhook endpoints. The webhook URLs are user-provided and point to the user's own Discord server or Slack workspace.

* **Data sent:** Alert and report text content (site name, status, uptime percentage, response times).
* **When sent:** On status changes (up/down), SSL expiry warnings, and scheduled periodic reports (if the respective channel is selected).
* **Discord Terms of Service:** https://discord.com/terms
* **Discord Privacy Policy:** https://discord.com/privacy
* **Slack Terms of Service:** https://slack.com/terms-of-service
* **Slack Privacy Policy:** https://slack.com/privacy-policy

== Changelog ==

= 1.0.3 =
* Removed "Active Installation Limits" restriction to comply with WordPress.org Guideline 5 (no trialware).
* Replaced rdap.org redirect service with PIR's authoritative RDAP server for .org domain expiration checks.
* Added PIR (Public Interest Registry) Terms/Privacy links to external services documentation.
* Removed unused edge proxy ping method and hardcoded credentials from codebase.

= 1.0.2 =
* Replaced NetworkCalc WHOIS API with RDAP (Registration Data Access Protocol) for domain expiration checks.
* RDAP queries are now sent directly to authoritative domain registries (Verisign for .com/.net).
* Updated external services documentation with verified Terms of Service and Privacy Policy links.

= 1.0.1 =
* Addressed compliance issues identified by the WordPress.org Plugin Review Team.
* Removed promotional and marketing language from the documentation and plugin UI.
* Added explicit disclosure and terms/privacy links for all third-party external services.
* Removed invalid/404 URL links from external service documentation.
* Updated bundled Chart.js library to the latest stable version.
* Corrected admin menu position for better WordPress core integration.

= 1.0.0 =
* Initial release.
