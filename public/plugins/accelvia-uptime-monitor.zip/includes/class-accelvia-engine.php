<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Accelvia_Engine {
    
    public function __construct() {
        add_action('accelvia_hourly_check', array($this, 'sync_monitors'));
        add_action('wp_ajax_accelvia_sync_now', array($this, 'ajax_sync_now'));
        add_action('accelvia_daily_log_prune', array($this, 'prune_old_logs'));
        add_action('accelvia_daily_pagespeed', array($this, 'update_pagespeed'));
    }

    public static function schedule_cron() {
        if (!wp_next_scheduled('accelvia_hourly_check')) {
            wp_schedule_event(time(), 'hourly', 'accelvia_hourly_check');
        } elseif (wp_get_schedule('accelvia_hourly_check') !== 'hourly') {
            wp_clear_scheduled_hook('accelvia_hourly_check');
            wp_schedule_event(time(), 'hourly', 'accelvia_hourly_check');
        }
        
        if (!wp_next_scheduled('accelvia_daily_log_prune')) {
            wp_schedule_event(time(), 'daily', 'accelvia_daily_log_prune');
        } elseif (wp_get_schedule('accelvia_daily_log_prune') !== 'daily') {
            wp_clear_scheduled_hook('accelvia_daily_log_prune');
            wp_schedule_event(time(), 'daily', 'accelvia_daily_log_prune');
        }
        
        if (!wp_next_scheduled('accelvia_daily_pagespeed')) {
            wp_schedule_event(time(), 'daily', 'accelvia_daily_pagespeed');
        } elseif (wp_get_schedule('accelvia_daily_pagespeed') !== 'daily') {
            wp_clear_scheduled_hook('accelvia_daily_pagespeed');
            wp_schedule_event(time(), 'daily', 'accelvia_daily_pagespeed');
        }
    }

    /**
     * Re-syncs the WordPress Alert Configs to the Vercel Edge Hub.
     */
    public function sync_edge_config() {
        if (get_option('accelvia_edge_fallback_enabled') !== 'yes') return;

        global $wpdb;
        $monitors = $wpdb->get_results("SELECT url, friendly_name FROM {$wpdb->prefix}accelvia_monitors"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        $payload = array(
            'tenant_hash' => md5(get_option('siteurl')),
            'monitors' => $monitors,
            'channels' => array(
                'discord' => get_option('accelvia_discord_webhook'),
                'slack'   => get_option('accelvia_slack_webhook'),
                'email'   => get_option('accelvia_alert_email'),
                'telegram_token'   => get_option('accelvia_telegram_token'),
                'telegram_chat_id' => get_option('accelvia_telegram_chat_id'),
                'whatsapp_num'     => get_option('accelvia_whatsapp_number'),
                'whatsapp_key'     => get_option('accelvia_whatsapp_apikey')
            )
        );

        $proxy_url = 'https://accelvia-api-proxy.vercel.app/api/sync-config';
        $api_secret = 'WHYLmVRu985TvN1d2qzIM0kXUZQ3SpEFbGje7s46ryfhtcOgolJDCiKxAPnwaB'; // Hardcoded shared architecture secret

        wp_remote_post($proxy_url, array(
            'body'    => wp_json_encode($payload),
            'headers' => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_secret
            ),
            'timeout' => 15
        ));
    }

    public static function clear_cron() {
        wp_clear_scheduled_hook('accelvia_hourly_check');
        wp_clear_scheduled_hook('accelvia_daily_log_prune');
        wp_clear_scheduled_hook('accelvia_daily_pagespeed');
    }

    /**
     * Main sync entry point. Pings all monitors locally,
     * checks SSL state, logs results, and triggers alerts.
     */
    public function sync_monitors($force_local = false) {
        global $wpdb;
        $monitors_table = esc_sql($wpdb->prefix . 'accelvia_monitors');
        $logs_table = esc_sql($wpdb->prefix . 'accelvia_logs');
        
        $monitors = $wpdb->get_results("SELECT * FROM {$monitors_table}"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if (empty($monitors)) return;

        // --- Process each monitor ---
        foreach ($monitors as $local) {
            $forced_ssl_down = false;
            $ssl_error_msg = '';

            // --- Absolute SSL Certificate Enforcement ---
            // Independently verify the target's raw SSL state before pinging.
            if (strpos($local->url, 'https://') === 0) {
                $host = wp_parse_url($local->url, PHP_URL_HOST);
                $stream_context = stream_context_create(array(
                    "ssl" => array(
                        "capture_peer_cert" => true,
                        "verify_peer" => true,
                        "verify_peer_name" => true,
                    )
                ));
                $client = @stream_socket_client("ssl://{$host}:443", $errno, $errstr, 5, STREAM_CLIENT_CONNECT, $stream_context);
                if (!$client) {
                    $forced_ssl_down = true;
                    $ssl_error_msg = '🔥 CRITICAL SSL DROP: The endpoint certificate has become invalid, expired, or was uninstalled.';
                } else {
                    $cont = stream_context_get_params($client);
                    if (isset($cont["options"]["ssl"]["peer_certificate"])) {
                        $cert = openssl_x509_parse($cont["options"]["ssl"]["peer_certificate"]);
                        if (isset($cert['validTo_time_t'])) {
                            $local->new_ssl_valid_to = gmdate('Y-m-d H:i:s', $cert['validTo_time_t']);
                        }
                    }
                    @fclose($client); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
                }
            }

            if ($forced_ssl_down) {
                // Instantly override all network proxy results with the SSL failure
                $new_status    = 'down';
                $response_time = 0;
                $status_code   = '0';
                $error_detail  = $ssl_error_msg;
            } else {
                // Approach B: Entirely local ping
                $local_result  = $this->ping_locally($local->url);
                $new_status    = $local_result['status'];
                $response_time = $local_result['response_time'];
                $status_code   = $local_result['status_code'];
                $error_detail  = $local_result['error'];
            }

            // Enrich error messages for down status
            if ($new_status === 'down' && empty($error_detail) && !empty($status_code) && $status_code !== '0') {
               $error_detail = "HTTP Error: Server responded with status code " . $status_code;
            } elseif ($new_status === 'down' && empty($error_detail)) {
               $error_detail = "Timeout: Endpoint completely unreachable.";
            }

            // --- SSL EXPIRY ALERTING LOGIC ---
            $new_ssl_valid = isset($local->new_ssl_valid_to) ? $local->new_ssl_valid_to : $local->ssl_valid_to;
            if (!empty($new_ssl_valid) && $new_status === 'up') {
                $days_remaining = (int)floor((strtotime($new_ssl_valid) - time()) / 86400);
                if ($days_remaining >= 0 && in_array($days_remaining, array(7, 3, 1))) {
                    $alert_key = "accelvia_ssl_alert_{$local->id}_{$days_remaining}";
                    if (!get_option($alert_key)) {
                        do_action('accelvia_ssl_warning', $local, $days_remaining);
                        update_option($alert_key, true);
                    }
                }
            }

            // Trigger alert if state changed
            if ($local->status !== 'checking' && $local->status !== $new_status && in_array($new_status, array('up', 'down'), true)) {
                do_action('accelvia_status_changed', $local, $new_status, $error_detail);
            }
            
            // Log the ping result
            $wpdb->insert($logs_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                'monitor_id'    => $local->id,
                'status'        => $new_status,
                'status_code'   => $status_code,
                'error_detail'  => $error_detail,
                'response_time' => $response_time,
                'checked_at'    => current_time('mysql')
            ));

            // Calculate uptime percentage from all historical logs
            $total_logs = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$logs_table} WHERE monitor_id = %d", $local->id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $up_logs = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$logs_table} WHERE monitor_id = %d AND status = 'up'", $local->id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            
            $uptime_percent = 100.00;
            if ($total_logs > 0) {
                $uptime_percent = round(($up_logs / $total_logs) * 100, 2);
            }

            // Calculate true average response time from successful pings
            $actual_avg = $wpdb->get_var($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                "SELECT AVG(response_time) FROM {$logs_table} WHERE monitor_id = %d AND status = 'up'", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $local->id
            ));
            $avg_response_time = $actual_avg ? round($actual_avg) : $response_time;

            // Update the monitor state
            $update_array = array(
                'status'            => $new_status,
                'avg_response_time' => $avg_response_time,
                'uptime_percent'    => $uptime_percent,
                'last_checked'      => current_time('mysql')
            );
            if (isset($local->new_ssl_valid_to)) {
                $update_array['ssl_valid_to'] = $local->new_ssl_valid_to;
            }
            $wpdb->update($monitors_table, $update_array, array('id' => $local->id)); // phpcs:ignore
        }

        // --- Phase 3: Periodic Reporting (covers ALL monitors) ---
        if ($force_local) {
            // Instant push test broadcast on manual sync
            foreach ($monitors as $monitor) {
                self::generate_report('Live Push Test', $monitor);
            }
        } elseif (get_option('accelvia_reports_enabled') === 'yes') {
            $last_report = get_option('accelvia_last_report_time', 0);
            $frequency = get_option('accelvia_reports_frequency', 'daily');
            
            $hours_required = 24; // default daily
            if ($frequency === 'weekly') $hours_required = 168;
            if ($frequency === 'hourly') $hours_required = 1;
            
            if (time() - $last_report >= ($hours_required * 3600)) {
                foreach ($monitors as $monitor) {
                    self::generate_report($frequency, $monitor);
                }
                update_option('accelvia_last_report_time', time());
            }
        }
    }


    /**
     * Local fallback: Ping a URL directly from the WordPress server.
     * Used when the Vercel edge proxy is unreachable or returns no result for a URL.
     *
     * @param string $url The URL to ping.
     * @return array Associative array with status, response_time, status_code, error.
     */
    private function ping_locally($url) {
        $start = microtime(true);

        $response = wp_remote_get($url, array(
            'timeout'     => 20,
            'redirection' => 3,
            'sslverify'   => true,
            'user-agent'  => 'Accelvia-Monitor/1.0 (Local Fallback)',
        ));

        $elapsed_ms = round((microtime(true) - $start) * 1000);

        if (is_wp_error($response)) {
            return array(
                'status'        => 'down',
                'response_time' => $elapsed_ms,
                'status_code'   => '0',
                'error'         => sanitize_text_field($response->get_error_message()),
            );
        }

        $http_code = wp_remote_retrieve_response_code($response);

        // Treat 2xx and 3xx as "up", everything else as "down"
        $is_up = ($http_code >= 200 && $http_code < 400);
        $error_msg = $is_up ? '' : "HTTP Error: Status code " . $http_code;

        // --- Keyword Defacement Check ---
        if ($is_up) {
            $keyword = get_option('accelvia_defacement_keyword');
            if (!empty($keyword)) {
                $body = wp_remote_retrieve_body($response);
                if (stripos($body, $keyword) === false) {
                    $is_up = false;
                    $error_msg = "Defacement Protection: Keyword '{$keyword}' missing from HTML body.";
                }
            }
        }

        return array(
            'status'        => $is_up ? 'up' : 'down',
            'response_time' => $elapsed_ms,
            'status_code'   => (string)$http_code,
            'error'         => $error_msg,
        );
    }

    /**
     * Delete logs older than the user-configured retention limit to prevent unbounded database growth.
     * Scheduled to run daily via WP-Cron.
     */
    public function prune_old_logs() {
        global $wpdb;
        $logs_table = esc_sql($wpdb->prefix . 'accelvia_logs');

        // Use user-defined retention setting or default to 90
        $retention_days = apply_filters('accelvia_log_retention_days', get_option('accelvia_log_retention_days', 90));

        $deleted = $wpdb->query($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            "DELETE FROM {$logs_table} WHERE checked_at < DATE_SUB(NOW(), INTERVAL %d DAY)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $retention_days
        ));

        if ($deleted > 0) {
            // Recalculate uptime for all monitors after pruning
            $monitors_table = esc_sql($wpdb->prefix . 'accelvia_monitors');
            $monitors = $wpdb->get_results("SELECT id FROM {$monitors_table}"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

            foreach ($monitors as $m) {
                $total = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$logs_table} WHERE monitor_id = %d", $m->id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $up    = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$logs_table} WHERE monitor_id = %d AND status = 'up'", $m->id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

                $uptime = ($total > 0) ? round(($up / $total) * 100, 2) : 100.00;
                
                $avg = $wpdb->get_var($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                    "SELECT AVG(response_time) FROM {$logs_table} WHERE monitor_id = %d AND status = 'up'", $m->id // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                ));

                $wpdb->update($monitors_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    'uptime_percent'    => $uptime,
                    'avg_response_time' => $avg ? round($avg) : 0,
                ), array('id' => $m->id));
            }
        }
    }

    private static function generate_report($frequency, $monitor) {
        global $wpdb;
        $hours = ($frequency === 'weekly') ? 168 : (($frequency === 'hourly') ? 1 : 24);
        
        // Aggregate Logs Mathematically
        $logs = $wpdb->get_results($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            "SELECT COUNT(*) as total_checks, 
                    SUM(CASE WHEN status != 'up' THEN 1 ELSE 0 END) as down_checks, 
                    AVG(response_time) as avg_ping 
             FROM {$wpdb->prefix}accelvia_logs 
             WHERE monitor_id = %d AND checked_at >= DATE_SUB(NOW(), INTERVAL %d HOUR)", 
            $monitor->id, $hours
        ));

        if (!empty($logs) && $logs[0]->total_checks > 0) {
            $data = $logs[0];
            $total = (int)$data->total_checks;
            $down = (int)$data->down_checks;
            $uptime = round((($total - $down) / $total) * 100, 2);
            $ping = round($data->avg_ping ?: 0);
            
            do_action('accelvia_periodic_report', $monitor, $frequency, $uptime, $ping, $down);
        }
    }

    public function ajax_sync_now() {
        check_ajax_referer('accelvia_sync_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        $this->sync_monitors(true); // force local check on manual sync
        $this->update_pagespeed(); // Force Lighthouse Trigger
        wp_send_json_success('Synced successfully via Local Push Node');
    }

    public function update_pagespeed() {
        global $wpdb;
        $monitors_table = esc_sql($wpdb->prefix . 'accelvia_monitors');
        $monitors = $wpdb->get_results("SELECT id, url FROM {$monitors_table}"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $api_key = get_option('accelvia_pagespeed_api_key');
        $key_param = !empty($api_key) ? "&key=" . urlencode($api_key) : "";

        foreach ($monitors as $m) {
            $encoded_url = urlencode($m->url);
            
            // Desktop
            $desktop_res = wp_remote_get("https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url={$encoded_url}&strategy=desktop{$key_param}", array('timeout' => 30));
            $desktop_score = 0;
            if (!is_wp_error($desktop_res)) {
                $code = wp_remote_retrieve_response_code($desktop_res);
                if ($code == 429) {
                    $desktop_score = -1;
                } else {
                    $data = json_decode(wp_remote_retrieve_body($desktop_res));
                    if (isset($data->lighthouseResult->categories->performance->score)) {
                        $desktop_score = round((float)$data->lighthouseResult->categories->performance->score * 100);
                    }
                }
            }

            // Mobile
            $mobile_res = wp_remote_get("https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url={$encoded_url}&strategy=mobile{$key_param}", array('timeout' => 30));
            $mobile_score = 0;
            if (!is_wp_error($mobile_res)) {
                $code = wp_remote_retrieve_response_code($mobile_res);
                if ($code == 429) {
                    $mobile_score = -1;
                } else {
                    $data = json_decode(wp_remote_retrieve_body($mobile_res));
                    if (isset($data->lighthouseResult->categories->performance->score)) {
                        $mobile_score = round((float)$data->lighthouseResult->categories->performance->score * 100);
                    }
                }
            }

            // Update db
            if ($desktop_score > 0 || $mobile_score > 0 || $desktop_score == -1 || $mobile_score == -1) {
                $wpdb->update($monitors_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                    'pagespeed_desktop' => $desktop_score,
                    'pagespeed_mobile' => $mobile_score
                ), array('id' => $m->id));
            }
        }
    }
}
