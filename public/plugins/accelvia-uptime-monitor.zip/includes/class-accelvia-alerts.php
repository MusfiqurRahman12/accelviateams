<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Accelvia_Alerts {

    public function __construct() {
        add_action('accelvia_status_changed', array($this, 'route_uptime_alert'), 10, 3);
        add_action('accelvia_security_alert', array($this, 'route_security_alert'), 10, 2);
        add_action('accelvia_periodic_report', array($this, 'route_periodic_report'), 10, 5);
        add_action('accelvia_ssl_warning', array($this, 'route_ssl_warning'), 10, 2);
    }

    public function route_ssl_warning($monitor, $days_remaining) {
        $icon = '🔐';
        $emoji_color = 16753920; // Orange

        $urgent_text = $days_remaining <= 1 ? "CRITICAL: " : "Warning: ";

        $plain_text = "{$icon} Accelvia SSL Expiry Alert\n";
        $plain_text .= "Node: {$monitor->friendly_name}\n";
        $plain_text .= "Target: {$monitor->url}\n";
        $plain_text .= "Status: {$urgent_text}SSL Certificate expires in {$days_remaining} day(s).\n";

        $html_email = "<h3>{$icon} Accelvia SSL Expiry Alert</h3><p><strong>Node:</strong> {$monitor->friendly_name}</p><p><strong>Target:</strong> {$monitor->url}</p><p><strong>Status:</strong> {$urgent_text}SSL Certificate expires in {$days_remaining} day(s).</p>";

        $discord_embed = array(
            'title' => "Accelvia SSL Expiry Alert",
            'description' => "{$urgent_text}SSL Certificate for **{$monitor->friendly_name}** expires in **{$days_remaining} day(s)**.",
            'color' => $emoji_color,
            'fields' => array(
                array('name' => 'Target Node', 'value' => $monitor->url, 'inline' => true)
            )
        );

        $slack_text = "*Node:* {$monitor->friendly_name}\n*Target:* {$monitor->url}\n*Status:* {$urgent_text}SSL expires in {$days_remaining} day(s).";
        $slack_blocks = array(
            'blocks' => array(
                array('type' => 'header', 'text' => array('type' => 'plain_text', 'text' => "{$icon} Accelvia SSL Expiry Alert", 'emoji' => true)),
                array('type' => 'section', 'text' => array('type' => 'mrkdwn', 'text' => $slack_text))
            )
        );

        $this->dispatch_all($plain_text, $html_email, "Accelvia SSL Alert ({$days_remaining} Days)", $discord_embed, $slack_blocks);
    }


    public function route_uptime_alert($monitor, $new_status, $error_detail = '') {
        $icon = $new_status === 'up' ? '🟢' : '🔴';
        $status_text = strtoupper($new_status);
        $emoji_color = $new_status === 'up' ? 3066993 : 15158332; // Green : Red

        // String formulation for Telegram and WhatsApp
        $plain_text = "{$icon} Accelvia Pulse Alert\n";
        $plain_text .= "Node: {$monitor->friendly_name}\n";
        $plain_text .= "Target: {$monitor->url}\n";
        $plain_text .= "Status: The endpoint is currently {$status_text}.\n";
        if (!empty($error_detail)) {
            $plain_text .= "Reason: {$error_detail}";
        }

        // HTML Formulation for Admin Email
        $error_html = !empty($error_detail) ? "<p style='color:#e11d48; padding: 10px; background: rgba(225, 29, 72, 0.1); border-radius: 4px; border: 1px solid #e11d48; margin-top: 15px;'><strong>Context:</strong> " . esc_html($error_detail) . "</p>" : "";
        $html_email = "<h3>{$icon} Accelvia Pulse Alert</h3><p><strong>Node:</strong> {$monitor->friendly_name}</p><p><strong>Target:</strong> {$monitor->url}</p><p><strong>Status:</strong> The endpoint is currently {$status_text}.</p>{$error_html}";

        // Rich Embed Formulation for Discord
        $fields = array(
            array('name' => 'Target Node', 'value' => $monitor->url, 'inline' => true),
            array('name' => 'Check Status', 'value' => $status_text, 'inline' => true)
        );
        if (!empty($error_detail)) {
            $fields[] = array('name' => 'Diagnostic Context', 'value' => $error_detail, 'inline' => false);
        }

        $discord_embed = array(
            'title' => "Accelvia Pulse Alert",
            'description' => "Status change detected for **{$monitor->friendly_name}**",
            'color' => $emoji_color,
            'fields' => $fields
        );

        // Slack Extracted Formulation
        $slack_text = "*Node:* {$monitor->friendly_name}\n*Target:* {$monitor->url}\n*Status:* {$status_text}";
        if (!empty($error_detail)) {
            $slack_text .= "\n\n*Diagnostics:* `{$error_detail}`";
        }
        $slack_blocks = array(
            'blocks' => array(
                array('type' => 'header', 'text' => array('type' => 'plain_text', 'text' => "{$icon} Accelvia Pulse Alert", 'emoji' => true)),
                array('type' => 'section', 'text' => array('type' => 'mrkdwn', 'text' => $slack_text))
            )
        );

        $this->dispatch_all($plain_text, $html_email, "Accelvia Host Node {$status_text}", $discord_embed, $slack_blocks);
    }

    public function route_security_alert($message, $severity) {
        $icon = $severity === 'critical' ? '🔴' : '⚠️';
        $severity_text = strtoupper($severity);
        $emoji_color = $severity === 'critical' ? 15158332 : 16776960; // Red : Yellow

        $plain_text = "{$icon} Accelvia Guardian Alert\n";
        $plain_text .= "Severity: {$severity_text}\n";
        $plain_text .= "Details: {$message}";

        $html_email = "<h3>{$icon} Accelvia Guardian Alert</h3><p><strong>Severity:</strong> {$severity_text}</p><p><strong>Event:</strong> {$message}</p>";

        $discord_embed = array(
            'title' => 'Accelvia Guardian Alert',
            'description' => "**Severity:** {$severity_text}\n\n**Event Details:**\n{$message}",
            'color' => $emoji_color
        );

        // Slack Extracted Formulation
        $slack_blocks = array(
            'blocks' => array(
                array('type' => 'header', 'text' => array('type' => 'plain_text', 'text' => "{$icon} Accelvia Guardian Alert", 'emoji' => true)),
                array('type' => 'section', 'text' => array('type' => 'mrkdwn', 'text' => "*Severity:* {$severity_text}\n*Details:* {$message}"))
            )
        );

        $this->dispatch_all($plain_text, $html_email, "Accelvia Security {$severity_text}", $discord_embed, $slack_blocks);
    }

    private function dispatch_all($plain_text, $html_email, $email_subject, $discord_embed, $slack_blocks = null) {
        
        // 1. Native Email Dispatch
        $email_address = get_option('accelvia_alert_email');
        if (!empty($email_address) && is_email($email_address)) {
            // Force HTML content type for the duration of this mail send
            add_filter('wp_mail_content_type', array($this, 'set_html_content_type'));
            wp_mail($email_address, $email_subject, $html_email);
            remove_filter('wp_mail_content_type', array($this, 'set_html_content_type'));
        }

        // 2. Discord Webhook Dispatch
        $discord_webhook = get_option('accelvia_discord_webhook');
        if (!empty($discord_webhook)) {
            wp_remote_post($discord_webhook, array(
                'headers' => array('Content-Type' => 'application/json'),
                'body' => json_encode(array('embeds' => array($discord_embed))),
                'timeout' => 5
            ));
        }

        // 2b. Slack Webhook Dispatch
        $slack_webhook = get_option('accelvia_slack_webhook');
        if (!empty($slack_webhook) && $slack_blocks) {
            wp_remote_post($slack_webhook, array(
                'headers' => array('Content-Type' => 'application/json'),
                'body' => json_encode($slack_blocks),
                'timeout' => 5
            ));
        }

        // 3. Telegram API Dispatch
        $telegram_token = get_option('accelvia_telegram_token');
        $telegram_chat_id = get_option('accelvia_telegram_chat_id');
        if (!empty($telegram_token) && !empty($telegram_chat_id)) {
            $api_url = "https://api.telegram.org/bot{$telegram_token}/sendMessage";
            wp_remote_post($api_url, array(
                'body' => array(
                    'chat_id' => $telegram_chat_id,
                    'text' => $plain_text
                ),
                'timeout' => 5
            ));
        }

        // 4. WhatsApp via CallMeBot REST API Dispatch
        $wa_number = get_option('accelvia_whatsapp_number');
        $wa_apikey = get_option('accelvia_whatsapp_apikey');
        if (!empty($wa_number) && !empty($wa_apikey)) {
            // Strip any illegal characters from phone number just in case
            $wa_number = preg_replace('/[^0-9+]/', '', $wa_number);
            $encoded_text = urlencode($plain_text);
            
            $wa_url = "https://api.callmebot.com/whatsapp.php?phone={$wa_number}&text={$encoded_text}&apikey={$wa_apikey}";
            wp_remote_get($wa_url, array('timeout' => 5));
        }
    }

    public function route_periodic_report($monitor, $frequency, $uptime, $ping, $down) {
        $channels = get_option('accelvia_reports_channels', array());
        if (empty($channels) || !is_array($channels)) return;

        $freq_label = ucfirst($frequency);
        $icon = $uptime >= 99 ? '🌟' : ($uptime >= 95 ? '⚡' : '⚠️');
        $emoji_color = $uptime >= 99 ? 3066993 : ($uptime >= 95 ? 16776960 : 15158332); // Green, Yellow, Red

        // Formulate PageSpeed Labels
        $psi_desk = isset($monitor->pagespeed_desktop) && $monitor->pagespeed_desktop > 0 ? $monitor->pagespeed_desktop : (isset($monitor->pagespeed_desktop) && $monitor->pagespeed_desktop == -1 ? 'Rate-Limited' : 'N/A');
        $psi_mob = isset($monitor->pagespeed_mobile) && $monitor->pagespeed_mobile > 0 ? $monitor->pagespeed_mobile : (isset($monitor->pagespeed_mobile) && $monitor->pagespeed_mobile == -1 ? 'Rate-Limited' : 'N/A');

        // Plain Text Gen
        $plain_text = "{$icon} Accelvia {$freq_label} Report\n";
        $plain_text .= "Node: {$monitor->friendly_name}\n";
        $plain_text .= "Uptime: {$uptime}%\n";
        $plain_text .= "Avg Latency: {$ping}ms\n";
        $plain_text .= "Lighthouse (Desktop): {$psi_desk}\n";
        $plain_text .= "Lighthouse (Mobile): {$psi_mob}\n";
        $plain_text .= "Incidents: {$down}";

        // HTML Gen
        $html_email = "<h3>{$icon} Accelvia {$freq_label} Report</h3><p><strong>Node:</strong> {$monitor->friendly_name}</p><ul><li><strong>Total Uptime:</strong> {$uptime}%</li><li><strong>Average Latency:</strong> {$ping}ms</li><li><strong>Lighthouse Desktop:</strong> {$psi_desk}</li><li><strong>Lighthouse Mobile:</strong> {$psi_mob}</li><li><strong>Crashes Logged:</strong> {$down}</li></ul>";

        // Discord Gen
        $discord_embed = array(
            'title' => "Accelvia {$freq_label} Network Report",
            'description' => "Aggregated Global Health for **{$monitor->friendly_name}**",
            'color' => $emoji_color,
            'fields' => array(
                array('name' => 'Global Uptime', 'value' => "{$uptime}%", 'inline' => true),
                array('name' => 'Avg Latency', 'value' => "{$ping}ms", 'inline' => true),
                array('name' => 'Crashes Detected', 'value' => (string)$down, 'inline' => true),
                array('name' => 'Lighthouse (Desk)', 'value' => (string)$psi_desk, 'inline' => true),
                array('name' => 'Lighthouse (Mob)', 'value' => (string)$psi_mob, 'inline' => true)
            )
        );

        // Slack Gen
        $slack_blocks = array(
            'blocks' => array(
                array('type' => 'header', 'text' => array('type' => 'plain_text', 'text' => "{$icon} Accelvia {$freq_label} Report", 'emoji' => true)),
                array('type' => 'section', 'text' => array('type' => 'mrkdwn', 'text' => "*Node:* {$monitor->friendly_name}\n*Uptime:* {$uptime}%\n*Avg Latency:* {$ping}ms\n*Lighthouse Desktop:* {$psi_desk}\n*Lighthouse Mobile:* {$psi_mob}\n*Crashes:* {$down}"))
            )
        );

        $this->dispatch_selective($plain_text, $html_email, "Accelvia {$freq_label} Review", $discord_embed, $channels, $slack_blocks);
    }

    private function dispatch_selective($plain_text, $html_email, $email_subject, $discord_embed, $channels, $slack_blocks = null) {
        // 1. Native Email 
        if (in_array('email', $channels)) {
            $email_address = get_option('accelvia_alert_email');
            if (!empty($email_address) && is_email($email_address)) {
                add_filter('wp_mail_content_type', array($this, 'set_html_content_type'));
                wp_mail($email_address, $email_subject, $html_email);
                remove_filter('wp_mail_content_type', array($this, 'set_html_content_type'));
            }
        }

        // 2. Discord Webhook 
        if (in_array('discord', $channels)) {
            $discord_webhook = get_option('accelvia_discord_webhook');
            if (!empty($discord_webhook)) {
                wp_remote_post($discord_webhook, array(
                    'headers' => array('Content-Type' => 'application/json'),
                    'body' => json_encode(array('embeds' => array($discord_embed))),
                    'timeout' => 5
                ));
            }
        }

        // 2b. Slack Webhook
        if (in_array('slack', $channels)) {
            $slack_webhook = get_option('accelvia_slack_webhook');
            if (!empty($slack_webhook) && $slack_blocks) {
                wp_remote_post($slack_webhook, array(
                    'headers' => array('Content-Type' => 'application/json'),
                    'body' => json_encode($slack_blocks),
                    'timeout' => 5
                ));
            }
        }

        // 3. Telegram API 
        if (in_array('telegram', $channels)) {
            $telegram_token = get_option('accelvia_telegram_token');
            $telegram_chat_id = get_option('accelvia_telegram_chat_id');
            if (!empty($telegram_token) && !empty($telegram_chat_id)) {
                $api_url = "https://api.telegram.org/bot{$telegram_token}/sendMessage";
                wp_remote_post($api_url, array(
                    'body' => array('chat_id' => $telegram_chat_id, 'text' => $plain_text),
                    'timeout' => 5
                ));
            }
        }

        // 4. WhatsApp (CallMeBot) 
        if (in_array('whatsapp', $channels)) {
            $wa_number = get_option('accelvia_whatsapp_number');
            $wa_apikey = get_option('accelvia_whatsapp_apikey');
            if (!empty($wa_number) && !empty($wa_apikey)) {
                $wa_number = preg_replace('/[^0-9+]/', '', $wa_number);
                $encoded_text = urlencode($plain_text);
                $wa_url = "https://api.callmebot.com/whatsapp.php?phone={$wa_number}&text={$encoded_text}&apikey={$wa_apikey}";
                wp_remote_get($wa_url, array('timeout' => 5));
            }
        }
    }

    public function set_html_content_type() {
        return 'text/html';
    }
}
