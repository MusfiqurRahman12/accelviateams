<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Accelvia_DB {

    const DB_VERSION = '1.0.3';

    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $monitors_table = $wpdb->prefix . 'accelvia_monitors';
        $logs_table = $wpdb->prefix . 'accelvia_logs';

        $sql = "CREATE TABLE {$monitors_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            url varchar(255) NOT NULL,
            friendly_name varchar(255) NOT NULL,
            status varchar(50) DEFAULT 'checking' NOT NULL,
            uptime_percent decimal(5,2) DEFAULT '100.00' NOT NULL,
            avg_response_time int(11) DEFAULT '0' NOT NULL,
            pagespeed_desktop int(11) DEFAULT '0' NOT NULL,
            pagespeed_mobile int(11) DEFAULT '0' NOT NULL,
            ssl_valid_to datetime DEFAULT NULL,
            last_checked datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;
        
        CREATE TABLE {$logs_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            monitor_id bigint(20) NOT NULL,
            status varchar(50) NOT NULL,
            status_code varchar(20) DEFAULT '' NOT NULL,
            error_detail varchar(255) DEFAULT '' NOT NULL,
            response_time int(11) NOT NULL,
            checked_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        // Store the DB version so we can detect upgrades
        update_option( 'accelvia_db_version', self::DB_VERSION );

        // Zero-Click Activation Logic
        $accelvia_current_count = $wpdb->get_var("SELECT COUNT(*) FROM " . esc_sql($monitors_table)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
        if ($accelvia_current_count == 0 && function_exists('get_site_url')) {
            $wpdb->insert($monitors_table, array( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                'user_id' => 1,
                'url' => get_site_url(),
                'friendly_name' => get_bloginfo('name') ?: 'Accelvia Host Node',
                'status' => 'checking'
            ));
        }
    }

    /**
     * Check if a DB schema upgrade is needed and run it.
     * Called on plugins_loaded to handle upgrades without re-activation.
     */
    public static function check_version() {
        if ( get_option( 'accelvia_db_version' ) !== self::DB_VERSION ) {
            self::create_tables();
        }
    }
}
