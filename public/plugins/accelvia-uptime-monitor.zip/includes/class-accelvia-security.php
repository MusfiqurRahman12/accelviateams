<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Accelvia_Security {
    public function __construct() {
        add_action('accelvia_daily_security_check', array($this, 'run_security_scan'));
    }

    public static function schedule_cron() {
        if (!wp_next_scheduled('accelvia_daily_security_check')) {
            wp_schedule_event(time(), 'daily', 'accelvia_daily_security_check');
        } elseif (wp_get_schedule('accelvia_daily_security_check') !== 'daily') {
            wp_clear_scheduled_hook('accelvia_daily_security_check');
            wp_schedule_event(time(), 'daily', 'accelvia_daily_security_check');
        }
    }

    public static function clear_cron() {
        wp_clear_scheduled_hook('accelvia_daily_security_check');
    }

    public function run_security_scan() {
        // Simple File Integrity check of the main WordPress files
        $critical_files = array(
            ABSPATH . 'wp-config.php',
            ABSPATH . 'index.php',
            ABSPATH . 'wp-settings.php'
        );

        foreach ($critical_files as $file) {
            if (file_exists($file)) {
                $hash = hash_file('md5', $file);
                $stored_hash = get_option('accelvia_hash_' . md5($file));
                
                if (!$stored_hash) {
                    update_option('accelvia_hash_' . md5($file), $hash);
                } elseif ($stored_hash !== $hash) {
                    $this->trigger_security_alert("File Modification Detected: " . basename($file), 'critical');
                    update_option('accelvia_hash_' . md5($file), $hash);
                }
            }
        }
        
        // Let's also check SSL on all our monitors natively
        global $wpdb;
        $monitors = $wpdb->get_results("SELECT url, friendly_name FROM {$wpdb->prefix}accelvia_monitors"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        
        foreach ($monitors as $accelvia_m) {
            $parsed = wp_parse_url($accelvia_m->url);
            if (!isset($parsed['host'])) continue;
            
            $host = $parsed['host'];
            $get = stream_context_create(array("ssl" => array("capture_peer_cert" => true)));
            try {
                $read = @stream_socket_client("ssl://".$host.":443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $get); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_stream_socket_client
                if ($read) {
                    $cert = stream_context_get_params($read);
                    $certinfo = openssl_x509_parse($cert['options']['ssl']['peer_certificate']);
                    $valid_from = gmdate('Y-m-d', $certinfo['validFrom_time_t']);
                    $valid_to = gmdate('Y-m-d', $certinfo['validTo_time_t']);
                    
                    $days_left = floor(($certinfo['validTo_time_t'] - time()) / (60 * 60 * 24));
                    
                    if ($days_left <= 14 && $days_left > 0) {
                        $this->trigger_security_alert("SSL Expires soon for {$accelvia_m->friendly_name} ({$days_left} days left)", 'warning');
                    } elseif ($days_left <= 0) {
                        $this->trigger_security_alert("SSL CERTIFICATE EXPIRED for {$accelvia_m->friendly_name}!", 'critical');
                    }
                }
            } catch (Exception $e) { } // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
            
            // 3. Domain Registration Expiration (via RDAP — the official IETF/ICANN successor to WHOIS)
            $domain_to_check = preg_replace('/^www\./', '', $host);
            $tld = strtolower(substr($domain_to_check, strrpos($domain_to_check, '.') + 1));

            // Map common TLDs to their authoritative RDAP servers.
            $rdap_servers = array(
                'com' => 'https://rdap.verisign.com/com/v1/',
                'net' => 'https://rdap.verisign.com/net/v1/',
                'org' => 'https://rdap.publicinterestregistry.org/rdap/',
            );

            if (isset($rdap_servers[$tld])) {
                $rdap_url = $rdap_servers[$tld] . 'domain/' . $domain_to_check;

                $rdap_res = wp_remote_get($rdap_url, array('timeout' => 15));
                if (!is_wp_error($rdap_res)) {
                    $rdap_body = wp_remote_retrieve_body($rdap_res);
                    $rdap_data = json_decode($rdap_body, true);
                    if (isset($rdap_data['events']) && is_array($rdap_data['events'])) {
                        foreach ($rdap_data['events'] as $event) {
                            if (isset($event['eventAction']) && 'expiration' === $event['eventAction'] && isset($event['eventDate'])) {
                                $expires_time = strtotime($event['eventDate']);
                                if ($expires_time) {
                                    $domain_days_left = floor(($expires_time - time()) / 86400);
                                    if ($domain_days_left <= 30 && $domain_days_left > 0) {
                                        $this->trigger_security_alert("Domain Expires soon for {$accelvia_m->friendly_name} ({$domain_days_left} days left)", 'warning');
                                    } elseif ($domain_days_left <= 0) {
                                        $this->trigger_security_alert("DOMAIN EXPIRED for {$accelvia_m->friendly_name}!", 'critical');
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        // 4. Vulnerability Scan (Native WordPress Transients)
        $plugin_updates = get_site_transient('update_plugins');
        if (isset($plugin_updates->response) && count($plugin_updates->response) > 0) {
            $outdated = count($plugin_updates->response);
            if ($outdated >= 3) { // Only alert if significant accumulation 
                $this->trigger_security_alert("Vulnerability Warning: {$outdated} plugins rely on outdated versions. Please update to block exploitation vectors.", 'warning');
            }
        }
    }
    
    private function trigger_security_alert($message_body, $severity = 'critical') {
        // Route through the centralized Accelvia_Alerts multi-channel dispatcher
        do_action('accelvia_security_alert', $message_body, $severity);
    }
}
